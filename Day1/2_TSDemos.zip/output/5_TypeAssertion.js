var data1 = "Hello, I am here";
console.log(data1.toUpperCase());
console.log(data1.toUpperCase());
var a1 = data1.length;
console.log(a1);
var a2 = data1.length;
console.log(a2);
var a3 = data1.length;
console.log(a3);

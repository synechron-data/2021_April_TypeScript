var empList;
empList = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Ramakant", city: "Delhi" },
    { id: 3, name: "Abhijeet", city: "Pune" },
    { id: 4, name: "Pravin", city: "Mumbai" },
    { id: 5, name: "Subodh", city: "Pune" }
];
var pune_emps = empList.filter(function (e) { return e.city === "Pune"; });
console.log(pune_emps);
var result1 = empList.find(function (e) { return e.id === 3; });
console.log(result1);
var result2 = empList.findIndex(function (e) { return e.id === 3; });
console.log(result2);
var result4 = empList.map(function (e) { return e.name.toUpperCase(); });
console.log(result4);

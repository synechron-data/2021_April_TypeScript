function add(x, y) {
    return x + y;
}
console.log(add(2, 3));
var s = Symbol("Hello");
var p = new Promise(function (resolve, reject) { });

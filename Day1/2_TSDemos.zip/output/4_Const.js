var env = "production";
console.log(env);
if (true) {
    var env_1 = "development";
    console.log("Block Scoped: ", env_1);
}
var obj = { id: 1 };
console.log(obj);
obj.id = 1000;
console.log(obj);

// var arr1 = [10, 20, 30];
// var arr2 = [10, 20, 30, "ABC", true, { id: 1 }];

// var arr3: number[];
// arr3 = [10, 20, 30];

// var arr4: Array<number>;
// arr4 = [10, 20, 30];

// var arr5 = new Array("Manish");
// console.log(arr5);

// var arr6 = Array.of(2);
// console.log(arr6);

// var arr7 = Array.from("Manish");
// console.log(arr7);

var empList: Array<{ id: number, name: string, city: string }>;
empList = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Ramakant", city: "Delhi" },
    { id: 3, name: "Abhijeet", city: "Pune" },
    { id: 4, name: "Pravin", city: "Mumbai" },
    { id: 5, name: "Subodh", city: "Pune" }
];

// for (let i = 0; i < empList.length; i++) {
//     console.log(`${i}       ${empList[i].name}`);
// }

// empList.forEach((item, index, arr) => {
//     console.log(`${index}       ${item.name}`);
// });

// for(const item of empList){
//     console.log(item.name);
// }

// for (const item of empList.entries()) {
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const [index, item] of empList.entries()) {
//     console.log(`${index}       ${item.name}`);
// }

var pune_emps = empList.filter(e => e.city === "Pune");
console.log(pune_emps);

var result1 = empList.find(e => e.id === 3);
console.log(result1);

var result2 = empList.findIndex(e => e.id === 3);
console.log(result2);

var result4 = empList.map(e => e.name.toUpperCase());
console.log(result4);
// Variables created are optionally typesafe
// Untyped Variable = No Type Safety, No Intellisense
// var data;
// data = 10;
// data = "ABC";

// Implicitly Typed
// var data = 10;
// // data = "ABC";           // Error: Type 'string' is not assignable to type 'number'.

// var s = "ANC";
// // s = 10;                  // Error: Type 'number' is not assignable to type 'string'       

// // Explicitly Typed
// var age: number;
// age = 10;
// // age = "ABC";                // Error: Type 'string' is not assignable to type 'number'.

// var city: string;
// city = "Pune";

// function add(x: any, y: any) {
//     return x + y;
// }

function add(x: number, y: number) {
    return x + y;
}

console.log(add(2, 3));
// console.log(add(2, "ABC"));
// console.log(add("ABC", "XYZ"));
// console.log(add("ABC", true));

var s: symbol = Symbol("Hello");
var p: Promise<void> = new Promise((resolve, reject) => { });

// JavaScript Types and API's
// number / string / boolean / undefined / Array / Object / Date / RegExp / Function / void
// Based on target and lib section configured in tsconfig.json

// TypeScript Types
// any / never / tuple / enum / interface / class / typeguards
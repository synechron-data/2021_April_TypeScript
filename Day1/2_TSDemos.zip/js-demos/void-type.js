// void expression

void function hello() {
    console.log("Hello World");
}

try {
    hello();
} catch (e) {
    console.log(e);
}
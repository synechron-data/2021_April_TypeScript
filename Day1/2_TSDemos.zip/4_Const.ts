// let j: number;
// j = 20;
// j = 10;

// const env;          // Compile Time Error: 'const' declarations must be initialized.

// let sname: "Synechron";
// sname = "Synechron";

const env = "production";
console.log(env);

// env = "development";        // Compile Time Error: Cannot assign to 'env' because it is a constant.
// console.log(env);

// const env = "development";        // Compile Time Error: Cannot redeclare block-scoped variable 'env'.
// console.log(env);

if (true) {
    const env = "development";
    console.log("Block Scoped: ", env);
}

const obj = { id: 1 };
console.log(obj);

// obj = { name: "Manish" };       // Compile Time Error: Cannot assign to 'obj' because it is a constant.

obj.id = 1000;
console.log(obj);

// Global Scope
// Local (Function) Scope
// Block Scope (Using let and const)

// var i = 10;
// var i = 20;
// console.log(i);

// function test() {
//     if (true) {
//         var i = "Hello";
//     }
//     return i;
// }

// console.log(test());

// // Hoisting
// a = "Hi";
// console.log(a);
// var a;

// var i = 100;
// console.log("Before, i is", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside, i is", i);
// }

// console.log("After, i is", i);

// ----------------------------------------------------------
// let i = 10;
// // let i = 20;         // Error: Cannot redeclare block-scoped variable 'i'
// console.log(i);

// function test() {
//     if (true) {
//         let i = "Hello";        // Scope of i is only within if statement
//     }
//     return i;                   // Compile Time Error
// }

// console.log(test());

// Hoisting - Not Supported
// a = "Hi";
// console.log(a);
// let a;

var i = 100;
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside, i is", i);
}

console.log("After, i is", i);
type Point = {
    x: number;
    y: number;
};

function test(point: Point) {
    return point.x * point.y;
}

console.log(test({ x: 10, y: 20 }));

var p: Point = { x: 1, y: 2 };
console.log(test(p));

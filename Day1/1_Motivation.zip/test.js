function test(point) {
    return point.x * point.y;
}
console.log(test({ x: 10, y: 20 }));
var p = { x: 1, y: 2 };
console.log(test(p));

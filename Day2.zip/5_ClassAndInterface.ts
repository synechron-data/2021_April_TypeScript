// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// // class Person implements IPerson {
// //     name: string;
// //     age: number;

// //     constructor(n: string, a: number) {
// //         this.name = n;
// //         this.age = a;
// //     }

// //     greet(message: string): string {
// //         return "Hello";
// //     };
// // }

// class Person implements IPerson {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     };
// }

// let p1: IPerson = new Person("Abhijeet", 38);
// let p2: IPerson = new Person("Ramakant", 38);

// console.log(p1.greet("Hi"));
// console.log(p2.greet("Hi"));

// -------------------------------------------------------- Multiple Interface Implementation

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// interface IEmployee {
//     doWork(): string;
// }

// class Person implements IPerson, IEmployee {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     };

//     doWork(): string {
//         return "I am learning TypeScript";
//     }
// }

// let p1: Person = new Person("Abhijeet", 38);

// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// ---------------------------------------------------------- Interface Extraction

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// interface IEmployee {
//     doWork(): string;
// }

// interface ICustomer {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     };

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     doShopping(): string {
//         return "Let us do it online";
//     }
// }

// // let p1: Person = new Person("Abhijeet", 38);
// // console.log(p1.greet("Hi"));
// // console.log(p1.doWork());
// // console.log(p1.doShopping());

// // Interface Extraction
// let p1: IPerson = new Person("Abhijeet", 38);
// console.log(p1.greet("Hi"));

// let p2: IEmployee = new Person("Abhijeet", 38);
// console.log(p2.doWork());

// let p3: ICustomer = new Person("Abhijeet", 38);
// console.log(p3.doShopping());

// ---------------------------------------------------------- Interface can extend other Interface

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// interface IEmployee extends IPerson {
//     doWork(): string;
// }

// interface ICustomer extends IPerson {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     };

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     doShopping(): string {
//         return "Let us do it online";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 38);
// console.log(p1.greet("Hi"));
// console.log();
// let p2: IEmployee = new Person("Abhijeet", 38);
// console.log(p2.greet("Good Morning"));
// console.log(p2.doWork());
// console.log();
// let p3: ICustomer = new Person("Abhijeet", 38);
// console.log(p3.greet("Namaste"));
// console.log(p3.doShopping());

// ---------------------------------------------------------- Interface can extend from Class(s)

// class Developer {
//     applyLeave() {

//     }
// }

// class Manager {
//     approveLeave() {

//     }
// }

// class DevMan extends Developer, Manager {

// }

// var d = new DevMan();
// d.applyLeave();
// d.approveLeave();

// ------------------------
// class BankCashier {
//     applyLoan() {

//     }
// }

// class BankManager {
//     approveLoan() {

//     }
// }

// class CashMan extends BankCashier, BankManager {

// }

// var d = new CashMan();
// d.applyLoan();
// d.approveLoan();

// ------------------------
// class Developer {
//     applyLeave() {
//         console.log("Apply Leave");
//     }
// }

// class Manager {
//     approveLeave() {
//         console.log("Approve Leave");
//     }
// }

// interface IDevMan extends Developer, Manager { }

// class DevMan implements IDevMan {
//     applyLeave(): void {
//         throw new Error("Method not implemented.");
//     }
//     approveLeave(): void {
//         throw new Error("Method not implemented.");
//     }
// }

// var d = new DevMan();
// d.applyLeave();
// d.approveLeave();

"use strict";
function insert(data) {
}
insert([1, "Manish"]);
//# sourceMappingURL=1_Tuple.js.map
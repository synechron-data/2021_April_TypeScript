System.config({
    paths: {
        "npm:": "./node_modules/"
    },
    map: {
        'jquery': 'npm:jquery/dist/jquery.min.js'
    }
});
// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence

// var arr1: number[] = [10, 20, 30, 40, 50];

// TypeGuard Array
// var arr2: (string | number)[] = ["Manish", 1];
// arr2 = ["Abhijeet", "Pune"];
// arr2 = [10, 20, 30, 40, 50];
// arr2 = [1, "Abhijeet"];
// arr2 = [1, "Abhijeet", "Pune", 411038];

// Tuple
// let dataRow: [string, number] = ["Manish", 1];
// dataRow = ["Abhijeet", "Pune"];
// dataRow = [10, 20, 30, 40, 50];
// dataRow = [1, "Abhijeet"];
// dataRow = ["Manish", 1, "Pune"];

function insert(data: [number, string]) {
    // Code to Insert data in Table
}

insert([1, "Manish"]);
// insert(["Manish", 1]);
// insert([1, 2, 3, 4, 5]);